<?php
// Prevent direct access.
if ( ! defined('ABSPATH')) {
  exit;
}
?>

<div class="c-calendar__footer"></div>
