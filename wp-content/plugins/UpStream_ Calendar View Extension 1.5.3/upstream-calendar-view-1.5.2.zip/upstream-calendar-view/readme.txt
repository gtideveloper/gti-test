=== UpStream Calendar View ===
Contributors: upstreamplugin, deenison, andergmartins
Requires at least: 4.5
Tested up to: 5.0
Requires PHP: 5.6
Stable tag: 1.5.2
License: GPL-3
License URI: https://www.gnu.org/licenses/gpl-3.0.html
