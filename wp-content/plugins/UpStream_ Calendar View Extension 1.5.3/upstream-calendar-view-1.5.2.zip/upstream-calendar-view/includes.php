<?php
define('UPSTREAM_CALENDAR_VIEW_VERSION', '1.5.2');

define('UPSTREAM_CALENDAR_VIEW_NAME', 'upstream-calendar-view');
define('UPSTREAM_CALENDAR_VIEW_API_URL', 'https://upstreamplugin.com/');
define('UPSTREAM_CALENDAR_VIEW_PLUGIN_FILE', dirname(__FILE__) . '/upstream-calendar-view.php');
define('UPSTREAM_CALENDAR_VIEW_ID', 6798);
define('UPSTREAM_CALENDAR_UPSTREAM_MIN_REQUIRED_VERSION', '1.30');
